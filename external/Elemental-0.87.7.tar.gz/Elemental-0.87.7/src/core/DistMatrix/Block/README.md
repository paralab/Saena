### `src/core/BlockDistMatrix/`

This folder contains the source code for the various partial specializations of
the `BlockDistMatrix` class; please see `include/El/core/BlockDistMatrix/` for 
the corresponding header-level prototypes and a detailed README explaining the 
various data distributions.
